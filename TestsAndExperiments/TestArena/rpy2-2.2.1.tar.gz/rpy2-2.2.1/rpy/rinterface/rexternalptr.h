#ifndef _RPY_PRIVATE_REXTPTR_H_
#define _RPY_PRIVATE_REXTPTR_H_

#ifndef _RPY_RINTERFACE_MODULE_
#error rexternalptr.h should not be included
#endif

static SEXP R_PyObject_decref(SEXP s);

#endif
